<?php

    Yii::import('zii.widgets.grid.CGridView');
    class GridViewWidget extends CGridView
    {
        
    }
?>
