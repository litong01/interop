YiiWheels Assets Folder
=======================

This folder should be used to held ***only*** orphan javascript, css or img files that will enhance the toolkit.
Each extension / widget should encapsulate its own assets so we keep this folder with as few files as possible.