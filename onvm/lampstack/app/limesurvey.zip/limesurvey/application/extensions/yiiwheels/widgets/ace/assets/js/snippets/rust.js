define('ace/snippets/rust', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "rust";

});
