<?php
class PluginBase extends \ls\pluginmanager\PluginBase
{

}