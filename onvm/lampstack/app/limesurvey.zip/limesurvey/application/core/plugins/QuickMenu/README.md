Plugin for LimeSurvey 2.5 to add extra quick-menu items.

What buttons to show can be configured in the Plugin Manager. Some buttons will be hidden due to user permission.

Requirements:

* LimeSurvey 2.5

How it looks:

![Quickmenu picture](assets/quickmenu.png)
