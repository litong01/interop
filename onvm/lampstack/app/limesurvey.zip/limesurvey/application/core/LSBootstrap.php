<?php
/**
 * For updating from 2.06 to 2.5.
 * 2.06 logout action still looks for this file at the end of the update process, causing an internal server error. 
 */
class LSBootstrap
{
}
