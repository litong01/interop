<?php

class AuthPluginBase extends \ls\pluginmanager\AuthPluginBase {

}